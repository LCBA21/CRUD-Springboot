package com.example.EmployeeCrud.controller;

import jakarta.persistence.*;

@Entity
@Table(name = "EmployeeTable")
public class Employee {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false,length = 45)
    private String First_Name;
    @Column(nullable = false,length = 45)
    private String Last_Name;

    @Column(nullable = false,length = 45)
    private String Job_Title;

    public Employee() {
    }

    public Employee(Integer id, String first_Name, String last_Name, String job_Title) {
        this.id = id;
        First_Name = first_Name;
        Last_Name = last_Name;
        Job_Title = job_Title;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirst_Name() {
        return First_Name;
    }

    public void setFirst_Name(String first_Name) {
        First_Name = first_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public void setLast_Name(String last_Name) {
        Last_Name = last_Name;
    }

    public String getJob_Title() {
        return Job_Title;
    }

    public void setJob_Title(String job_Title) {
        Job_Title = job_Title;
    }

}
