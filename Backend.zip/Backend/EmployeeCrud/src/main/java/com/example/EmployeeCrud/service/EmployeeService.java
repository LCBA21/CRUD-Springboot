package com.example.EmployeeCrud.service;

import com.example.EmployeeCrud.controller.Employee;
import com.example.EmployeeCrud.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository Emp_Repo;

    //Add/Save Employee
   public Employee saveEmployee(Employee employee){
       return Emp_Repo.save(employee);
    }


    public Employee updateEmployee(Integer id,Employee updatedEmployee ){

       Optional<Employee> existingEmployee =Emp_Repo.findById(id);
       if(existingEmployee.isPresent()){

           Employee employeeToUpdate=existingEmployee.get();

           employeeToUpdate.setFirst_Name(updatedEmployee.getFirst_Name());
           employeeToUpdate.setLast_Name(updatedEmployee.getLast_Name());
           employeeToUpdate.setJob_Title(updatedEmployee.getJob_Title());

           return Emp_Repo.save(employeeToUpdate);
       }
       else {
           return null;
       }

    }

    public  void deleteEmployee(Integer id){
       if(Emp_Repo.existsById(id)){
           Emp_Repo.deleteById(id);
       }

    }


    public Employee getEmployeeById(Integer id){
       Optional<Employee> employee =Emp_Repo.findById(id);
       return employee.orElse(null);
    }

    public List<Employee> getAllEmployees() {
        Iterable<Employee> iterable = Emp_Repo.findAll();
        List<Employee> employeeList = new ArrayList<>();
        iterable.forEach(employeeList::add);
        return employeeList;
    }




}
