package com.example.EmployeeCrud.exception;

public class EmployeeNotFoundException  extends  RuntimeException{

    public  EmployeeNotFoundException(Integer id){

        super("Employee with id "+id+" could not be found");
    }

}
