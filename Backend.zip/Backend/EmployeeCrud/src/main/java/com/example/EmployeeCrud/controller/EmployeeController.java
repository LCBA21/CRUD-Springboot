package com.example.EmployeeCrud.controller;

import com.example.EmployeeCrud.exception.EmployeeNotFoundException;
import com.example.EmployeeCrud.repository.EmployeeRepository;
import com.example.EmployeeCrud.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class EmployeeController {

    @Autowired
    private EmployeeService service;


    @Autowired
    private EmployeeRepository Emp_Repo;



    @PostMapping("/add")
    public Employee AddEmployee(@RequestBody Employee employee){
        return service.saveEmployee(employee);
    }

    @PutMapping("/update/{id}")
    public Employee updateEmployee(@PathVariable Integer id,@RequestBody Employee updatedEmployee ){
        return service.updateEmployee(id,updatedEmployee);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteEmployee(@PathVariable Integer id) {
        service.deleteEmployee(id);
    }

    @GetMapping("/employee/{id}")
    public  Employee getEmployeeById(@PathVariable Integer id){
        return Emp_Repo.findById(id)
                .orElseThrow(() ->new EmployeeNotFoundException(id));
    }

    @GetMapping("/employees")
    public List<Employee> getAllEmployee(){
       return service.getAllEmployees();
    }
}
